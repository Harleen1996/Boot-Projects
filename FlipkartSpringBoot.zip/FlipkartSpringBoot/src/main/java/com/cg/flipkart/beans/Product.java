package com.cg.flipkart.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;

@Entity
public class Product {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="productIdGenerator")
	@SequenceGenerator(name="productIdGenerator", sequenceName="productId_seq", initialValue=50001)
	private int productId;
	private String productName;
	private float price;
	
	@ManyToOne
	private Customer customer;
	
	
}
