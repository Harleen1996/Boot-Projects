package com.cg.flipkart.beans;

import java.util.Map;

import javax.persistence.CascadeType;
import javax.persistence.Embedded;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;


@Entity
public class Customer {
	
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="customerIdGenerator")
	@SequenceGenerator(name="customerIdGenerator", sequenceName="customerId_seq", initialValue=101)
	private int customerId;
	private String firstName;
	private String lastName;
	private String emailId;
	private String dob;
	
	@Embedded
	private Address deliveryAddress;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="customer", orphanRemoval=true)
	@MapKey
	private Map<Integer, Order> orders;
	
	@OneToMany(cascade=CascadeType.ALL, mappedBy="customer", orphanRemoval=true)
	@MapKey
	private Map<Integer, Product> products;
	
}
