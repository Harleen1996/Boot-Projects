package com.cg.flipkart.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;

@Entity
public class Bill {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="billIdGenerator")
	@SequenceGenerator(name="billIdGenerator", sequenceName="billId_seq", initialValue=800001)
	private int billId;
}
